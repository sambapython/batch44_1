print "this is file2"
def fun():
	print "this is fun in file2"

if __name__ == "__main__":
	pass