'''
import module1
module1.file2.fun()
'''
from module1 import file2
file2.fun()