a=10
b=20
c=a+b
def fun():
	print "this is fun in f1"

print "a=%s, b=%s, c=%s"%(a,b,c)
fun()