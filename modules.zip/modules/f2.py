a=10
b=20
c=a+b
d=400
def fun():
	print "this is fun in f2"

print "a=%s, b=%s, c=%s"%(a,b,c)
fun()